"""Private fictional host files exercise incremental MCP setup and rollback."""
import contextlib
import ctypes
import io
import json
import os
from pathlib import Path
import stat
import re
import shutil
import subprocess
import sys
import tempfile
try:
    import tomllib
except ModuleNotFoundError:
    tomllib = None
from types import SimpleNamespace
import unittest
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import setup_mcp as setup


class SetupMcpTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.base = Path(temporary.name)
        self.root = self.base / "fictional-package"
        self.host = self.base / "fictional-host"
        self.root.mkdir()
        self.host.mkdir()
        (self.root / "scripts").mkdir()
        (self.root / "scripts/mcp_server.py").write_text("# fictional entry only\n", encoding="utf8")
        interpreter = Path(setup._entry(self.root)["command"])
        interpreter.parent.mkdir(parents=True)
        interpreter.write_bytes(b"fictional-not-executed")
        self.path = self.host / "mcp.json"
        self.local = {"workbuddy_config": str(self.host), "a2a": {"token": "fictional-local-secret"}}
        self.write(self.root / "local.json", self.local)
        self.document = {"preserved-root": {"private": "fictional-root-secret"}, "mcpServers": {
            "unrelated": {"command": "fictional-command", "env": {"API_KEY": "fictional-other-secret"}}}}
        self.write(self.path, self.document)
        self.trust = self.host / "mcp-approvals.json"
        self.trust.write_bytes(b"fictional-trust-must-not-change")

    @staticmethod
    def write(path, document):
        path.write_text(json.dumps(document, ensure_ascii=False, indent=2) + "\n", encoding="utf8")

    def read(self):
        return json.loads(self.path.read_text(encoding="utf8"))

    def install(self):
        return setup.install(self.root, confirm=True, expected=setup.preview(self.root)["fingerprint"])

    def command(self, *args):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            code = setup.main([*args, "--root", str(self.root)])
        wire = output.getvalue()
        for secret in ("fictional-local-secret", "fictional-root-secret", "fictional-other-secret", "later-sensitive"):
            self.assertNotIn(secret, wire)
        return code, json.loads(wire)

    def test_preview_is_read_only_and_only_exposes_its_public_entry(self):
        before = {str(p.relative_to(self.base)): p.read_bytes() for p in self.base.rglob("*") if p.is_file()}
        code, result = self.command()
        self.assertEqual(code, 0)
        self.assertFalse(result["conflict"])
        self.assertFalse(result["already_configured"])
        self.assertEqual(result["config_path"], str(self.path))
        self.assertEqual(result["entry"], setup._entry(self.root))
        self.assertNotIn("env", result["entry"])
        self.assertEqual(result["entry"]["args"][-2:], ["--host", "workbuddy"])
        self.assertIn(".mcp-env", result["entry"]["command"])
        self.assertNotIn(".a2a-env", result["entry"]["command"])
        self.assertNotIn("unrelated", json.dumps(result))
        after = {str(p.relative_to(self.base)): p.read_bytes() for p in self.base.rglob("*") if p.is_file()}
        self.assertEqual(before, after)

    def test_missing_tomllib_keeps_workbuddy_preview_and_refuses_codex_safely(self):
        original = setup._digest(self.path.read_bytes())
        with mock.patch.object(setup, "tomllib", None), \
             mock.patch.dict(os.environ, {"CODEX_HOME": str(self.host)}):
            self.assertEqual(setup.preview(self.root)["host"], "workbuddy")
            with self.assertRaisesRegex(setup.SetupError, "Python 3.11"):
                setup.preview(self.root, host="codex")
        self.assertEqual(setup._digest(self.path.read_bytes()), original)
        self.assertFalse((self.root / "runtime").exists())

    def test_install_preserves_other_configuration_and_private_exact_backup(self):
        raw = self.path.read_bytes()
        installed = self.install()
        current = self.read()
        self.assertEqual(current["preserved-root"], self.document["preserved-root"])
        self.assertEqual(current["mcpServers"]["unrelated"], self.document["mcpServers"]["unrelated"])
        self.assertEqual(current["mcpServers"][setup.NAME], setup._entry(self.root))
        self.assertEqual((self.root / installed["backup"] / "before.raw").read_bytes(), raw)
        self.assertEqual(self.trust.read_bytes(), b"fictional-trust-must-not-change")
        self.assertEqual(len(list(self.host.iterdir())), 2)
        code, repeated = self.command("install", "--confirm", "--expected", setup.preview(self.root)["fingerprint"])
        self.assertEqual(code, 0)
        self.assertEqual(repeated["state"], "unchanged")
        self.assertEqual(len(list((self.root / "runtime/mcp-backups").iterdir())), 1)

    def test_same_name_conflict_is_reported_without_existing_entry(self):
        self.document["mcpServers"][setup.NAME] = {"command": "private-command", "env": {"KEY": "fictional-other-secret"}}
        self.write(self.path, self.document)
        code, result = self.command()
        self.assertTrue(result["conflict"])
        self.assertNotIn("private-command", json.dumps(result))
        before = self.path.read_bytes()
        code, result = self.command("install", "--confirm", "--expected", result["fingerprint"])
        self.assertEqual(code, 2)
        self.assertEqual(self.path.read_bytes(), before)
        self.assertFalse((self.root / "runtime").exists())

    def test_confirmation_and_matching_preview_are_required(self):
        fingerprint = setup.preview(self.root)["fingerprint"]
        for confirm, expected in ((False, fingerprint), (True, None), (True, "0" * 64)):
            with self.subTest(confirm=confirm, expected=expected):
                with self.assertRaises(setup.SetupError):
                    setup.install(self.root, confirm=confirm, expected=expected)
        self.assertEqual(self.read(), self.document)
        self.assertFalse((self.root / "runtime").exists())

    def test_pure_json_required_and_invalid_content_never_printed_or_changed(self):
        invalid = ['// fictional-other-secret\n{"mcpServers":{}}', '{"mcpServers":{},}',
                   '{"mcpServers":{},"mcpServers":{"secret":"fictional-other-secret"}}',
                   '{"mcpServers":{},"number":NaN}', '[]', '{"mcpServers":null}',
                   '\ufeff{"mcpServers":{}}']
        for text in invalid:
            with self.subTest(text=text):
                self.path.write_text(text, encoding="utf8")
                raw = self.path.read_bytes()
                code, result = self.command("preview")
                self.assertEqual(code, 2)
                self.assertIn("error", result)
                self.assertEqual(self.path.read_bytes(), raw)
                self.assertFalse((self.root / "runtime").exists())

    def test_missing_host_file_and_default_directory_are_supported_without_probe_writes(self):
        self.local.pop("workbuddy_config")
        self.write(self.root / "local.json", self.local)
        home = self.base / "fictional-home"
        home.mkdir()
        with mock.patch.object(Path, "home", return_value=home):
            preview = setup.preview(self.root)
            self.assertEqual(preview["config_path"], str(home / ".workbuddy/mcp.json"))
            self.assertFalse((home / ".workbuddy").exists())
            installed = setup.install(self.root, confirm=True, expected=preview["fingerprint"])
            new_path = home / ".workbuddy/mcp.json"
            self.assertEqual(json.loads(new_path.read_text(encoding="utf8"))["mcpServers"][setup.NAME], setup._entry(self.root))
            self.assertFalse((self.root / installed["backup"] / "before.raw").exists())
            setup.rollback(self.root, installed["installation_id"], confirm=True)
            self.assertEqual(json.loads(new_path.read_text(encoding="utf8")), {"mcpServers": {}})

    def test_unprepared_environment_refuses_install_before_backup(self):
        Path(setup._entry(self.root)["command"]).unlink()
        with self.assertRaises(setup.SetupError):
            self.install()
        self.assertFalse((self.root / "runtime").exists())
        self.assertEqual(self.read(), self.document)

    def test_change_since_preview_refuses_overwrite(self):
        fingerprint = setup.preview(self.root)["fingerprint"]
        self.document["later-field"] = "kept"
        self.write(self.path, self.document)
        with self.assertRaises(setup.SetupError):
            setup.install(self.root, confirm=True, expected=fingerprint)
        self.assertEqual(self.read(), self.document)
        self.assertFalse((self.root / "runtime").exists())

    def test_change_during_staging_is_detected_immediately_before_replace(self):
        stage = setup._stage
        def racing(path, raw, template):
            temporary = stage(path, raw, template)
            if path == self.path:
                self.document["concurrent"] = "kept"
                self.write(self.path, self.document)
            return temporary
        with mock.patch.object(setup, "_stage", side_effect=racing):
            with self.assertRaises(setup.SetupError):
                self.install()
        self.assertEqual(self.read(), self.document)
        self.assertEqual(list(self.host.glob(".mcp-*")), [])

    def test_atomic_replace_failure_keeps_original_configuration(self):
        replace = setup._replace
        def failed_target(path, temporary):
            if path == self.path:
                raise OSError("fictional-other-secret")
            return replace(path, temporary)
        raw = self.path.read_bytes()
        with mock.patch.object(setup, "_replace", side_effect=failed_target):
            code, result = self.command("install", "--confirm", "--expected", setup.preview(self.root)["fingerprint"])
        self.assertEqual(code, 2)
        self.assertIn("error", result)
        self.assertEqual(self.path.read_bytes(), raw)
        self.assertEqual(list(self.host.glob(".mcp-*")), [])

    def test_rollback_only_removes_matching_entry_and_preserves_later_changes(self):
        installed = self.install()
        document = self.read()
        document["later-root"] = {"kept": True}
        document["mcpServers"]["later-server"] = {"command": "later", "env": {"KEY": "later-sensitive"}}
        self.write(self.path, document)
        code, result = self.command("rollback", "--confirm", "--installation", installed["installation_id"])
        self.assertEqual(code, 0)
        self.assertEqual(result["state"], "removed")
        del document["mcpServers"][setup.NAME]
        self.assertEqual(self.read(), document)
        self.assertEqual(setup.rollback(self.root, installed["installation_id"], confirm=True)["state"], "unchanged")
        self.assertEqual(self.trust.read_bytes(), b"fictional-trust-must-not-change")

    def test_rollback_refuses_modified_entry_or_unconfirmed_or_redirected_record(self):
        installed = self.install()
        identity = installed["installation_id"]
        for confirm, record in ((False, identity), (True, "../escape")):
            with self.assertRaises(setup.SetupError):
                setup.rollback(self.root, record, confirm=confirm)
        document = self.read()
        document["mcpServers"][setup.NAME]["env"] = {"KEY": "later-sensitive"}
        self.write(self.path, document)
        code, result = self.command("rollback", "--confirm", "--installation", identity)
        self.assertEqual(code, 2)
        self.assertEqual(self.read(), document)
        manifest = self.root / installed["backup"] / "manifest.json"
        record = json.loads(manifest.read_text(encoding="utf8"))
        record["config_path"] = str(self.base / "another-host/mcp.json")
        self.write(manifest, record)
        with self.assertRaises(setup.SetupError):
            setup.rollback(self.root, identity, confirm=True)

    def test_rollback_concurrent_change_is_not_overwritten(self):
        installed = self.install()
        stage = setup._stage
        concurrent = self.read()
        concurrent["added-during-rollback"] = "kept"
        def racing(path, raw, template):
            temporary = stage(path, raw, template)
            if path == self.path:
                self.write(self.path, concurrent)
            return temporary
        with mock.patch.object(setup, "_stage", side_effect=racing), self.assertRaises(setup.SetupError):
            setup.rollback(self.root, installed["installation_id"], confirm=True)
        self.assertEqual(self.read(), concurrent)
        self.assertEqual(list(self.host.glob(".mcp-*")), [])

    def test_private_staging_protects_empty_files_before_writing(self):
        security = setup._security
        observed = []
        def secure(path, template):
            if path.name.startswith(".mcp-"):
                self.assertEqual(path.read_bytes(), b"")
                observed.append(path)
            return security(path, template)
        with mock.patch.object(setup, "_security", side_effect=secure):
            installed = self.install()
            setup.rollback(self.root, installed["installation_id"], confirm=True)
        self.assertGreaterEqual(len(observed), 4)

    def test_hardlinked_configuration_is_refused(self):
        linked = self.base / "fictional-linked-private-copy"
        os.link(self.path, linked)
        with self.assertRaises(setup.SetupError):
            setup.preview(self.root)
        self.assertEqual(self.path.read_bytes(), linked.read_bytes())

    def test_windows_reparse_point_is_refused_before_read(self):
        lstat = Path.lstat
        def marked(path, *args, **kwargs):
            result = lstat(path, *args, **kwargs)
            if path == self.host:
                return SimpleNamespace(st_mode=result.st_mode, st_nlink=1, st_file_attributes=0x400)
            return result
        with mock.patch.object(Path, "lstat", marked), self.assertRaises(setup.SetupError):
            setup.preview(self.root)

    def test_symlinked_host_or_backup_directory_is_refused(self):
        actual = self.base / "real-host"
        self.host.rename(actual)
        try:
            self.host.symlink_to(actual, target_is_directory=True)
        except OSError:
            self.skipTest("Creating Windows symlinks requires permission")
        with self.assertRaises(setup.SetupError):
            setup.preview(self.root)
        self.host.unlink()
        actual.rename(self.host)
        (self.root / "runtime").mkdir()
        backups = self.root / "runtime/mcp-backups"
        backups.symlink_to(self.base, target_is_directory=True)
        with self.assertRaises(setup.SetupError):
            self.install()
        self.assertEqual(self.read(), self.document)

    @unittest.skipUnless(os.name == "nt", "Windows DACL retention")
    def test_windows_target_and_backup_keep_original_dacl(self):
        from ctypes import wintypes
        def dacl(path):
            api = ctypes.WinDLL("advapi32", use_last_error=True)
            api.GetFileSecurityW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.LPVOID,
                                            wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
            needed = wintypes.DWORD()
            api.GetFileSecurityW(str(path), 4, None, 0, ctypes.byref(needed))
            data = ctypes.create_string_buffer(needed.value)
            self.assertTrue(api.GetFileSecurityW(str(path), 4, data, needed, ctypes.byref(needed)))
            pointer, present, defaulted = ctypes.c_void_p(), wintypes.BOOL(), wintypes.BOOL()
            api.GetSecurityDescriptorDacl.argtypes = [wintypes.LPVOID, ctypes.POINTER(wintypes.BOOL),
                                                     ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(wintypes.BOOL)]
            self.assertTrue(api.GetSecurityDescriptorDacl(data, ctypes.byref(present), ctypes.byref(pointer), ctypes.byref(defaulted)))
            self.assertTrue(present.value)
            size = ctypes.c_ushort.from_address(pointer.value + 2).value
            return ctypes.string_at(pointer, size)
        original = dacl(self.path)
        installed = self.install()
        self.assertEqual(dacl(self.path), original)
        self.assertEqual(dacl(self.root / installed["backup"] / "before.raw"), original)
        setup.rollback(self.root, installed["installation_id"], confirm=True)
        self.assertEqual(dacl(self.path), original)


@unittest.skipIf(tomllib is None, "Codex TOML setup needs Python 3.11 or newer")
class CodexSetupMcpTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.base = Path(temporary.name)
        self.root = self.base / "fictional-package"
        self.home = self.base / "fictional-codex-home"
        self.root.mkdir()
        self.home.mkdir()
        (self.root / "scripts").mkdir()
        (self.root / "scripts/mcp_server.py").write_text("# fictional public entry\n", encoding="utf8")
        interpreter = Path(setup._entry(self.root, "codex")["command"])
        interpreter.parent.mkdir(parents=True)
        interpreter.write_bytes(b"fictional-not-executed")
        self.path = self.home / "config.toml"
        self.original = ('# preserve local comments\r\nmodel = "fictional-model"\r\n'
                         'sample_day = 2026-01-02\r\nsample_number = nan\r\n'
                         '[features]\r\nfictional_flag = true\r\n'
                         '[mcp_servers.unrelated]\r\ncommand = "fictional-other"\r\n'
                         '[mcp_servers.unrelated.env]\r\nPRIVATE_VALUE = "fictional-private-config"\r\n'
                         '# trailing comment with no newline').encode("utf8")
        self.path.write_bytes(self.original)
        self.auth = self.home / "auth.json"
        self.auth.write_bytes(b"fictional-auth-never-read")
        (self.root / "local.json").write_bytes(b"fictional-not-json-and-not-read")
        env = mock.patch.dict(os.environ, {"CODEX_HOME": str(self.home)})
        env.start()
        self.addCleanup(env.stop)

    def install(self):
        return setup.install(self.root, host="codex", confirm=True,
                             expected=setup.preview(self.root, host="codex")["fingerprint"])

    def command(self, *args):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            code = setup.main([*args, "--root", str(self.root), "--host", "codex"])
        wire = output.getvalue()
        self.assertFalse(any(value in wire for value in ("fictional-private-config", "fictional-auth-never-read", "fictional-other")))
        return code, json.loads(wire)

    def assert_same_bytes(self, left, right):
        self.assertEqual(setup._digest(left), setup._digest(right))

    def test_codex_preview_is_read_only_public_and_never_calls_cli(self):
        before = {str(p): setup._digest(p.read_bytes()) for p in self.base.rglob("*") if p.is_file()}
        with mock.patch("subprocess.run") as cli:
            code, result = self.command()
            cli.assert_not_called()
        self.assertEqual(code, 0)
        self.assertEqual(result["host"], "codex")
        self.assertEqual(result["config_path"], str(self.path))
        self.assertEqual(result["entry"]["args"][-2:], ["--host", "codex"])
        self.assertNotIn("cwd", result["entry"])
        self.assertFalse(result["conflict"])
        after = {str(p): setup._digest(p.read_bytes()) for p in self.base.rglob("*") if p.is_file()}
        self.assertTrue(before == after)

    def test_codex_append_preserves_exact_original_prefix_other_semantics_and_backup(self):
        with mock.patch("subprocess.run") as cli:
            installed = self.install()
            cli.assert_not_called()
        current = self.path.read_bytes()
        block = setup._codex_block(setup._entry(self.root, "codex"))
        self.assertTrue(current.startswith(self.original))
        self.assert_same_bytes(current, self.original + block)
        self.assert_same_bytes((self.root / installed["backup"] / "before.raw").read_bytes(), self.original)
        parsed = tomllib.loads(current.decode("utf8"))
        self.assertTrue(parsed["mcp_servers"][setup.NAME] == setup._entry(self.root, "codex"))
        self.assertTrue(setup._same_toml(setup._outside_codex_entry(parsed),
                                        setup._outside_codex_entry(tomllib.loads(self.original.decode()))))
        record = json.loads((self.root / installed["backup"] / "manifest.json").read_text())
        self.assertEqual(record["managed_block_version"], 1)
        self.assertEqual(record["managed_block_hash"], setup._digest(block))
        self.assertEqual(self.install()["state"], "unchanged")
        self.assert_same_bytes(self.auth.read_bytes(), b"fictional-auth-never-read")

    def test_codex_rollback_removes_only_exact_block_and_keeps_later_bytes(self):
        installed = self.install()
        later = b'\n# later user comment\n[mcp_servers.later]\ncommand = "later-public"\n'
        self.path.write_bytes(self.path.read_bytes() + later)
        code, result = self.command("rollback", "--confirm", "--installation", installed["installation_id"])
        self.assertEqual(code, 0)
        self.assertEqual(result["state"], "removed")
        self.assert_same_bytes(self.path.read_bytes(), self.original + later)
        self.assertEqual(setup.rollback(self.root, installed["installation_id"], confirm=True, host="codex")["state"], "unchanged")
        self.assert_same_bytes(self.auth.read_bytes(), b"fictional-auth-never-read")

    def test_codex_conflict_including_identical_unmanaged_entry_is_not_overwritten(self):
        block = setup._codex_block(setup._entry(self.root, "codex"))
        unmanaged = b'\n'.join(line for line in block.split(b'\n') if line not in {setup._CODEX_BEGIN, setup._CODEX_END})
        for body in (b'\n[mcp_servers."ai-collaboration"]\ncommand="fictional-private-config"\n', unmanaged):
            with self.subTest(kind=setup._digest(body)):
                self.path.write_bytes(self.original + body)
                code, result = self.command()
                self.assertEqual(code, 0)
                self.assertTrue(result["conflict"])
                self.assertEqual(self.command("install", "--confirm", "--expected", result["fingerprint"])[0], 2)
                self.assert_same_bytes(self.path.read_bytes(), self.original + body)
                self.assertFalse((self.root / "runtime").exists())

    def test_invalid_toml_and_closed_inline_servers_fail_without_rewrite_or_backup(self):
        cases = (b'[broken\nprivate="fictional-private-config"', b'mcp_servers="fictional-private-config"',
                 b'mcp_servers = {}\n', b'mcp_servers = { other = { command = "fictional-other" } }\n')
        for index, raw in enumerate(cases):
            with self.subTest(index=index):
                self.path.write_bytes(raw)
                if index < 2:
                    self.assertEqual(self.command()[0], 2)
                else:
                    fingerprint = setup.preview(self.root, host="codex")["fingerprint"]
                    self.assertEqual(self.command("install", "--confirm", "--expected", fingerprint)[0], 2)
                self.assert_same_bytes(self.path.read_bytes(), raw)
                self.assertFalse((self.root / "runtime").exists())

    def test_reserved_dangling_markers_are_not_guessed_or_appended(self):
        for marker in (setup._CODEX_BEGIN, setup._CODEX_END):
            raw = self.original + b'\n' + marker + b'\n'
            self.path.write_bytes(raw)
            with self.subTest(marker=marker), self.assertRaises(setup.SetupError):
                self.install()
            self.assert_same_bytes(self.path.read_bytes(), raw)
            self.assertFalse((self.root / "runtime").exists())

    def test_codex_rollback_refuses_changed_marker_comment_block_or_entry(self):
        installed = self.install()
        complete = self.path.read_bytes()
        cases = [complete.replace(setup._CODEX_BEGIN, setup._CODEX_BEGIN + b'-changed'),
                 complete.replace(setup._CODEX_END, setup._CODEX_END + b'-changed'),
                 complete.replace(setup._CODEX_END, b'# user modified this block\n' + setup._CODEX_END),
                 complete + setup._CODEX_BEGIN + b'\n',
                 complete.replace(b'"--host", "codex"', b'"--host", "changed"'),
                 self.original + b'\n' + setup._CODEX_BEGIN + b'\n' + setup._CODEX_END + b'\n']
        for index, raw in enumerate(cases):
            self.path.write_bytes(raw)
            with self.subTest(index=index), self.assertRaises(setup.SetupError):
                setup.rollback(self.root, installed["installation_id"], confirm=True, host="codex")
            self.assert_same_bytes(self.path.read_bytes(), raw)

    def test_codex_rollback_requires_matching_host_path_and_block_manifest(self):
        installed = self.install()
        path = self.root / installed["backup"] / "manifest.json"
        original = path.read_bytes()
        for change in ("host", "path", "hash", "version", "missing"):
            record = json.loads(original)
            if change == "host": record["host"] = "workbuddy"
            elif change == "path": record["config_path"] += ".elsewhere"
            elif change == "hash": record["managed_block_hash"] = "0" * 64
            elif change == "version": record["managed_block_version"] = 2
            else: record.pop("managed_block_hash")
            path.write_text(json.dumps(record), encoding="utf8")
            current = self.path.read_bytes()
            with self.subTest(change=change), self.assertRaises(setup.SetupError):
                setup.rollback(self.root, installed["installation_id"], confirm=True, host="codex")
            self.assert_same_bytes(self.path.read_bytes(), current)
        path.write_bytes(original)

    def test_block_safely_renders_unicode_control_quotes_backslashes_and_newlines(self):
        desired = {"command": 'C:\\fictional\\汉字🤖\\a"b\nnext\tline.exe',
                   "args": ['-X', 'utf8', '-B', 'line\n[mcp_servers.evil]\ncommand="injected"',
                            'back\\slash', 'quotes"', 'controls\b\f\r\t\x00', 'emoji🤖']}
        block = setup._codex_block(desired)
        parsed = tomllib.loads(block.decode("utf8"))
        self.assertTrue(parsed["mcp_servers"][setup.NAME] == desired)
        self.assertEqual(set(parsed["mcp_servers"]), {setup.NAME})
        self.assertEqual(block.splitlines().count(setup._CODEX_BEGIN), 1)
        self.assertEqual(block.splitlines().count(setup._CODEX_END), 1)
        with self.assertRaises(setup.SetupError):
            setup._codex_block({"command": '\ud800', "args": []})

    def test_codex_semantic_guard_and_size_limit_refuse_before_backup(self):
        original_factory = setup._codex_block
        def polluted(desired):
            return original_factory(desired) + b'\n[another_unrelated_section]\nflag=true\n'
        with mock.patch.object(setup, "_codex_block", side_effect=polluted), self.assertRaises(setup.SetupError):
            self.install()
        self.assert_same_bytes(self.path.read_bytes(), self.original)
        self.assertFalse((self.root / "runtime").exists())
        with mock.patch.object(setup, "MAX_CONFIG_BYTES", len(self.original) + 1), self.assertRaises(setup.SetupError):
            self.install()
        self.assert_same_bytes(self.path.read_bytes(), self.original)

    def test_codex_cas_rechecks_before_install_and_rollback_publication(self):
        stage = setup._stage
        later = b'\n# concurrent private edit\n'
        def racing(path, raw, template):
            temporary = stage(path, raw, template)
            if path == self.path:
                self.path.write_bytes(self.path.read_bytes() + later)
            return temporary
        with mock.patch.object(setup, "_stage", side_effect=racing), self.assertRaises(setup.SetupError):
            self.install()
        self.assert_same_bytes(self.path.read_bytes(), self.original + later)
        installed = self.install()
        current = self.path.read_bytes()
        with mock.patch.object(setup, "_stage", side_effect=racing), self.assertRaises(setup.SetupError):
            setup.rollback(self.root, installed["installation_id"], confirm=True, host="codex")
        self.assert_same_bytes(self.path.read_bytes(), current + later)
        self.assertEqual(list(self.home.glob(".mcp-*")), [])

    def test_codex_home_default_missing_file_and_relative_override(self):
        with mock.patch.dict(os.environ, {"CODEX_HOME": "relative"}), self.assertRaises(setup.SetupError):
            setup.preview(self.root, host="codex")
        fake_home = self.base / "another-home"
        fake_home.mkdir()
        with mock.patch.dict(os.environ, {"CODEX_HOME": ""}), mock.patch.object(Path, "home", return_value=fake_home):
            result = setup.preview(self.root, host="codex")
            self.assertEqual(result["config_path"], str(fake_home / ".codex/config.toml"))
            self.assertFalse((fake_home / ".codex").exists())

    def test_codex_first_install_with_missing_config_has_no_original_backup(self):
        self.path.unlink()
        installed = self.install()
        self.assertFalse((self.root / installed["backup"] / "before.raw").exists())
        self.assertIn(setup.NAME, tomllib.loads(self.path.read_text(encoding="utf8"))["mcp_servers"])
        setup.rollback(self.root, installed["installation_id"], confirm=True, host="codex")
        self.assert_same_bytes(self.path.read_bytes(), b'')
        self.assert_same_bytes(self.auth.read_bytes(), b"fictional-auth-never-read")

    def test_codex_hardlinks_rejected_and_dacl_applied_before_private_copy(self):
        copy_path = self.base / "hardlinked-private"
        os.link(self.path, copy_path)
        with self.assertRaises(setup.SetupError):
            setup.preview(self.root, host="codex")
        copy_path.unlink()
        security = setup._security
        seen = []
        def secure(path, template):
            if path.name.startswith(".mcp-"):
                self.assertEqual(path.stat().st_size, 0)
                seen.append(path)
            return security(path, template)
        with mock.patch.object(setup, "_security", side_effect=secure):
            self.install()
        self.assertTrue(seen)

    @unittest.skipUnless(os.name == "nt", "Windows DACL retention")
    def test_codex_config_keeps_original_windows_security_descriptor(self):
        from ctypes import wintypes
        def descriptor_hash(path):
            api = ctypes.WinDLL("advapi32", use_last_error=True)
            api.GetFileSecurityW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.LPVOID,
                                            wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
            needed = wintypes.DWORD()
            api.GetFileSecurityW(str(path), 4, None, 0, ctypes.byref(needed))
            buffer = ctypes.create_string_buffer(needed.value)
            self.assertTrue(api.GetFileSecurityW(str(path), 4, buffer, needed, ctypes.byref(needed)))
            return setup._digest(buffer.raw)
        before = descriptor_hash(self.path)
        installed = self.install()
        self.assertEqual(descriptor_hash(self.path), before)
        setup.rollback(self.root, installed["installation_id"], confirm=True, host="codex")
        self.assertEqual(descriptor_hash(self.path), before)


if __name__ == "__main__":
    unittest.main()
