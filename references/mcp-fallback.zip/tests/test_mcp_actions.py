"""MCP source and response boundaries, with synthetic registered chats only."""
import asyncio
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import platform
import sys
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
from mcp_actions import McpActions
from mcp_server import Inflight, TOOLS, metadata_from
import send
import a2a_transport


class ActionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.local = {"machine_name": platform.node(), "device_id": "pc",
                      "a2a": {"message_delivery": True}}
        self.book = {"version": 1, "peers": {
            "SenderA": {"device_id": "pc", "software": "workbuddy", "conversation_id": "wb-a", "verified": True},
            "SenderB": {"device_id": "pc", "software": "workbuddy", "conversation_id": "wb-b", "verified": True},
            "Codex": {"device_id": "pc", "software": "codex", "conversation_id": "cx", "verified": True},
        }}
        self.save()
        self.core = Mock(return_value={"state": "accepted", "to": "Codex", "stage": "native_host"})
        self.actions = McpActions(self.root, core=self.core)
        self.meta = {"workbuddy.ai/conversationId": "wb-a"}

    def save(self):
        (self.root / "local.json").write_text(json.dumps(self.local), encoding="utf-8")
        (self.root / "peers.json").write_text(json.dumps(self.book), encoding="utf-8")

    def invoke(self, text="check", meta=None):
        return self.actions.invoke("send_message", {"to": "Codex", "text": text}, self.meta if meta is None else meta)

    def test_only_target_and_body_cross_to_existing_core(self):
        text = "中文\n引号'$()` 与 @skill:test"
        self.assertEqual(self.invoke(text), {"state": "accepted", "to": "Codex", "stage": "native_host"})
        args, kwargs = self.core.call_args
        self.assertEqual(args, ({"mode": "send", "to": "Codex", "text": text}, self.root))
        self.assertEqual(kwargs, {"sender_context": {"CODEBUDDY_SESSION_ID": "wb-a"}})
        self.core.assert_called_once()

    def test_missing_metadata_never_falls_back_to_startup_environment(self):
        with patch.dict(os.environ, {"CODEBUDDY_SESSION_ID": "wb-a", "CODEX_THREAD_ID": "cx"}):
            for meta in ({}, None, {"workbuddy.ai/conversationId": ""}, {"conversation_id": "wb-a"}):
                with self.subTest(meta=meta):
                    result = self.actions.invoke("send_message", {"to": "Codex", "text": "message"}, meta)
                    self.assertEqual(result["state"], "not_sent")
        self.core.assert_not_called()

    def test_unregistered_disabled_unverified_and_nonlocal_sources_are_rejected(self):
        for change in ("unknown", "disabled", "unverified", "nonlocal", "duplicate"):
            with self.subTest(change=change):
                original = json.loads(json.dumps(self.book))
                meta = self.meta
                if change == "unknown": meta = {"workbuddy.ai/conversationId": "hidden-child"}
                if change == "disabled": self.book["peers"]["SenderA"]["enabled"] = False
                if change == "unverified": self.book["peers"]["SenderA"]["verified"] = False
                if change == "nonlocal": self.book["peers"]["SenderA"]["device_id"] = "other"
                if change == "duplicate": self.book["peers"]["Alias"] = dict(self.book["peers"]["SenderA"])
                self.save()
                self.assertEqual(self.invoke(meta=meta)["state"], "not_sent")
                self.book = original
        self.core.assert_not_called()

    def test_managed_registration_disabled_is_not_normalized_away(self):
        self.local["a2a"]["managed_ui"] = True
        self.book["peers"]["SenderA"]["enabled"] = False
        self.save()
        self.assertEqual(self.invoke()["state"], "not_sent")
        self.core.assert_not_called()

    def test_model_arguments_cannot_supply_source_credentials_or_native_operations(self):
        for extra in ("source", "from", "origin", "sender_context", "_meta", "token", "mode", "permit", "root"):
            with self.subTest(extra=extra):
                args = {"to": "Codex", "text": "message", extra: "injected"}
                self.assertEqual(self.actions.invoke("send_message", args, self.meta)["state"], "not_sent")
        self.assertEqual(self.actions.invoke("native-deliver", {"to": "Codex", "text": "x"}, self.meta)["state"], "not_sent")
        self.core.assert_not_called()

    def test_all_business_tools_resolve_current_source(self):
        for tool, args in (("list_peers", {}), ("send_status", {"to": "Codex"})):
            with self.subTest(tool=tool):
                self.assertEqual(self.actions.invoke(tool, args, {})["state"], "not_sent")
        self.core.assert_not_called()
        self.core.return_value = {"peers": [{"name": "Codex", "software": "codex", "device": "pc", "token": "FAKE_SECRET"}]}
        result = self.actions.invoke("list_peers", {}, self.meta)
        self.assertEqual(result, {"peers": [{"name": "Codex", "software": "codex", "device": "pc"}]})
        self.assertEqual(self.core.call_args.kwargs["sender_context"]["CODEBUDDY_SESSION_ID"], "wb-a")

    def test_two_concurrent_chats_on_one_connection_never_share_source(self):
        barrier = threading.Barrier(2)
        seen = []
        def core(request, root, *, sender_context):
            source = sender_context["CODEBUDDY_SESSION_ID"]
            seen.append((request["text"], source))
            barrier.wait(timeout=5)
            return {"state": "accepted", "to": source}
        actions = McpActions(self.root, core=core)
        with patch.dict(os.environ, {"CODEX_THREAD_ID": "cx", "CODEBUDDY_SESSION_ID": "stale"}), ThreadPoolExecutor(2) as pool:
            futures = [pool.submit(actions.invoke, "send_message", {"to": "Codex", "text": "call " + chat},
                                   {"workbuddy.ai/conversationId": chat}) for chat in ("wb-a", "wb-b")]
            results = [f.result(timeout=6) for f in futures]
            self.assertTrue(all(r == {"state": "accepted", "to": "Codex"} for r in results))
            self.assertCountEqual(seen, [("call wb-a", "wb-a"), ("call wb-b", "wb-b")])
            self.assertEqual(os.environ["CODEBUDDY_SESSION_ID"], "stale")
            self.assertEqual(os.environ["CODEX_THREAD_ID"], "cx")

    def test_results_and_errors_do_not_leak_raw_backend_fields(self):
        for result in (
            {"state": "accepted", "to": "Codex", "native_id": "private-id", "reply": "FAKE_SECRET"},
            {"state": "uncertain", "to": "Codex", "error": "FAKE_SECRET", "debug": {"token": "FAKE_SECRET"}},
            {"state": "not_sent", "error": "FAKE_SECRET"},
        ):
            with self.subTest(state=result["state"]):
                self.core.return_value = result
                output = self.invoke("original body")
                self.assertNotIn("FAKE_SECRET", json.dumps(output))
                self.assertNotIn("private-id", json.dumps(output))
                if output["state"] != "accepted": self.assertIn("original body", output["error"])
        self.core.side_effect = RuntimeError("FAKE_SECRET")
        output = self.invoke()
        self.assertEqual(output["state"], "uncertain")
        self.assertNotIn("FAKE_SECRET", json.dumps(output))

    def test_malformed_metadata_invalid_arguments_and_body_limit_never_send(self):
        for chat in (" wb-a", "wb-a\n", 12, "a" * 201):
            self.assertEqual(self.invoke(meta={"workbuddy.ai/conversationId": chat})["state"], "not_sent")
        for args in ({"to": "Codex", "text": ""}, {"to": "Codex"}, {"to": "C\nx", "text": "x"},
                     {"to": "Codex", "text": "中" * 22000}):
            self.assertEqual(self.actions.invoke("send_message", args, self.meta)["state"], "not_sent")
        self.core.assert_not_called()

    def test_legacy_result_addresses_cannot_reach_the_old_reply_branch(self):
        for target in ("A2A-123", "a2a-123", "A2a-123"):
            result = self.actions.invoke("send_message", {"to": target, "text": "old reply"}, self.meta)
            self.assertEqual(result["state"], "not_sent")
        self.core.assert_not_called()

    def test_invalid_unicode_and_backend_target_or_stage_never_escape(self):
        for args in ({"to": "Codex", "text": "\ud800"}, {"to": "\ud800", "text": "ok"}):
            result = self.actions.invoke("send_message", args, self.meta)
            self.assertEqual(result["state"], "not_sent")
            json.dumps(result, ensure_ascii=False).encode("utf-8")
        self.core.assert_not_called()
        self.core.return_value = {"state": "accepted", "to": "FAKE_SECRET", "stage": "native_host"}
        self.assertEqual(self.invoke()["to"], "Codex")
        self.core.return_value = {"state": "accepted", "to": "Codex", "stage": "FAKE_SECRET"}
        self.assertEqual(self.invoke()["state"], "uncertain")
        self.assertNotIn("FAKE_SECRET", json.dumps(self.invoke()))

    def test_legacy_mode_is_not_implicitly_activated_or_used(self):
        self.local["a2a"]["message_delivery"] = False
        self.save()
        self.assertEqual(self.invoke()["state"], "not_sent")
        self.core.assert_not_called()

    def test_core_rechecks_configuration_after_source_preflight(self):
        for change in ("mode", "verified", "enabled"):
            with self.subTest(change=change):
                self.local["a2a"]["message_delivery"] = True
                self.book["peers"]["SenderA"].update(verified=True, enabled=True)
                self.save()
                def loader(root):
                    before = send.load_config(root)
                    if change == "mode": self.local["a2a"]["message_delivery"] = False
                    else: self.book["peers"]["SenderA"][change] = False
                    self.save()
                    return before
                actions = McpActions(self.root, core=send.run, config_loader=loader)
                with patch.object(send, "invoke") as native, patch.object(a2a_transport, "invoke") as transport:
                    result = actions.invoke("send_message", {"to": "Codex", "text": "review"}, self.meta)
                    self.assertEqual(result["state"], "not_sent")
                    native.assert_not_called()
                    transport.assert_not_called()

    def test_metadata_and_schema_do_not_offer_a_source_parameter(self):
        self.assertEqual(set(TOOLS[0][2]), {"to", "text"})
        class Model:
            def model_dump(self, **kwargs): return {"workbuddy.ai/conversationId": "wb-a"}
        class Context:
            meta = Model()
        self.assertEqual(metadata_from(Context()), self.meta)

    def test_codex_uses_request_thread_id_and_ignores_session_or_other_host(self):
        actions = McpActions(self.root, host="codex", core=self.core)
        result = actions.invoke("send_message", {"to": "SenderA", "text": "direct"},
                                {"threadId": "cx", "sessionId": "not-current",
                                 "workbuddy.ai/conversationId": "wb-a"})
        self.assertEqual(result, {"state": "accepted", "to": "SenderA", "stage": "native_host"})
        self.assertEqual(self.core.call_args.kwargs, {"sender_context": {"CODEX_THREAD_ID": "cx"}})

    def test_codex_never_uses_parent_session_or_startup_chat_as_source(self):
        actions = McpActions(self.root, host="codex", core=self.core)
        with patch.dict(os.environ, {"CODEX_THREAD_ID": "cx", "CODEBUDDY_SESSION_ID": "wb-a"}):
            for meta in ({}, {"sessionId": "cx"}, {"threadId": "child", "sessionId": "cx"},
                         {"threadId": "wb-a"}, {"threadId": "cx\n"},
                         {"workbuddy.ai/conversationId": "wb-a"}):
                with self.subTest(meta=meta):
                    self.assertEqual(actions.invoke("list_peers", {}, meta)["state"], "not_sent")
        self.core.assert_not_called()

    def test_codex_and_workbuddy_do_not_share_environment_or_metadata_policy(self):
        self.book["peers"]["CodexB"] = {"device_id": "pc", "software": "codex",
                                         "conversation_id": "cx-b", "verified": True}
        self.save()
        seen = []
        barrier = threading.Barrier(3)
        def core(request, root, *, sender_context):
            seen.append((request["text"], dict(sender_context)))
            barrier.wait(timeout=5)
            return {"state": "accepted"}
        codex = McpActions(self.root, host="codex", core=core)
        wb = McpActions(self.root, host="workbuddy", core=core)
        with patch.dict(os.environ, {"CODEX_THREAD_ID": "wrong-startup",
                                     "CODEBUDDY_SESSION_ID": "wrong-wb"}), ThreadPoolExecutor(3) as pool:
            jobs = [(codex, "a", {"threadId": "cx"}), (codex, "b", {"threadId": "cx-b"}),
                    (wb, "w", {"workbuddy.ai/conversationId": "wb-a", "threadId": "cx-b"})]
            futures = [pool.submit(action.invoke, "send_message", {"to": "SenderB", "text": text}, meta)
                       for action, text, meta in jobs]
            self.assertTrue(all(job.result(timeout=6)["state"] == "accepted" for job in futures))
            self.assertEqual(os.environ["CODEX_THREAD_ID"], "wrong-startup")
            self.assertEqual(os.environ["CODEBUDDY_SESSION_ID"], "wrong-wb")
        self.assertCountEqual(seen, [("a", {"CODEX_THREAD_ID": "cx"}), ("b", {"CODEX_THREAD_ID": "cx-b"}),
                                     ("w", {"CODEBUDDY_SESSION_ID": "wb-a"})])

    def test_codex_rechecks_current_registration_for_all_three_tools(self):
        actions = McpActions(self.root, host="codex", core=self.core)
        for tool, args in (("list_peers", {}), ("send_status", {"to": "SenderA"}),
                           ("send_message", {"to": "SenderA", "text": "checked"})):
            for field in ("verified", "enabled"):
                with self.subTest(tool=tool, field=field):
                    self.book["peers"]["Codex"].update(verified=True, enabled=True)
                    self.book["peers"]["Codex"][field] = False
                    self.save()
                    self.assertEqual(actions.invoke(tool, args, {"threadId": "cx"})["state"], "not_sent")
        self.core.assert_not_called()


class InflightTests(unittest.IsolatedAsyncioTestCase):
    async def test_cancelled_caller_keeps_capacity_until_actual_send_finishes(self):
        started, release = threading.Event(), threading.Event()
        def action(*args):
            started.set()
            release.wait(timeout=5)
            return {"state": "accepted"}
        runner = Inflight(1)
        caller = asyncio.create_task(runner.call(action, "send_message", {}, {}))
        await asyncio.to_thread(started.wait, 2)
        caller.cancel()
        with self.assertRaises(asyncio.CancelledError): await caller
        self.assertEqual(len(runner.tasks), 1)
        result = await runner.call(action, "send_message", {}, {})
        self.assertEqual(result["state"], "not_sent")
        release.set()
        await runner.finish()
        await asyncio.sleep(0)
        self.assertEqual(len(runner.tasks), 0)


if __name__ == "__main__":
    unittest.main()
