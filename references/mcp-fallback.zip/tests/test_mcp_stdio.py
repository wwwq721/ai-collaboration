"""Official MCP SDK over actual stdio; all profiles and the final send are fake."""
import asyncio
import importlib.util
import json
import os
from pathlib import Path
import platform
import sys
import tempfile
import unittest

HAS_SDK = importlib.util.find_spec("mcp") is not None
if HAS_SDK:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client

SCRIPTS = Path(__file__).resolve().parent.parent / "scripts"


@unittest.skipUnless(HAS_SDK, "MCP SDK is not installed in this test interpreter")
class StdioTests(unittest.IsolatedAsyncioTestCase):
    HOST = "workbuddy"
    META_KEY = "workbuddy.ai/conversationId"
    SOURCE_A, SOURCE_B, TARGET = "wb-a", "wb-b", "Codex"

    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        local = {"machine_name": platform.node(), "device_id": "pc", "a2a": {"message_delivery": True}}
        peers = {"version": 1, "peers": {
            "SenderA": {"software": "workbuddy", "device_id": "pc", "conversation_id": "wb-a", "verified": True},
            "SenderB": {"software": "workbuddy", "device_id": "pc", "conversation_id": "wb-b", "verified": True},
            "Codex": {"software": "codex", "device_id": "pc", "conversation_id": "cx", "verified": True},
            "CodexB": {"software": "codex", "device_id": "pc", "conversation_id": "cx-b", "verified": True},
        }}
        for name, value in (("local.json", local), ("peers.json", peers)):
            (self.root / name).write_text(json.dumps(value), encoding="utf-8")
        self.capture = self.root / "synthetic-core-calls.jsonl"
        self.driver = self.root / "driver.py"
        self.driver.write_text('''import sys,asyncio,json,threading,time
from pathlib import Path
sys.path.insert(0,sys.argv[1])
import a2a_transport
from mcp_server import serve
root=Path(sys.argv[2]); capture=Path(sys.argv[3]); lock=threading.Lock()
def final_stub(root_,local,peer,mode,text="",source="",message_id=None,origin=None,**kwargs):
    time.sleep(0.03)
    with lock, capture.open("a",encoding="utf-8") as stream:
        stream.write(json.dumps({"mode":mode,"source":origin["conversation_id"],"text":text,"target":peer["alias"]},ensure_ascii=False)+"\\n")
    return {"state":"accepted","to":peer["alias"],"stage":"native_host","debug":"FAKE_PRIVATE_DATA"}
a2a_transport.invoke=final_stub
asyncio.run(serve(root,sys.argv[4]))
''', encoding="utf-8")
        # A real host pool may inherit an unrelated startup chat. Only per-call
        # Host metadata must select the sender.
        env = {"CODEX_THREAD_ID": "stale-codex", "CODEBUDDY_SESSION_ID": "stale-workbuddy"}
        self.params = StdioServerParameters(command=sys.executable,
                                            args=["-X", "utf8", "-B", str(self.driver), str(SCRIPTS),
                                                  str(self.root), str(self.capture), self.HOST], env=env)

    @staticmethod
    def body(result):
        assert len(result.content) == 1
        assert not result.structuredContent
        return json.loads(result.content[0].text)

    def calls(self):
        if not self.capture.exists(): return []
        return [json.loads(line) for line in self.capture.read_text(encoding="utf-8").splitlines()]

    async def test_management_discovery_succeeds_without_a_chat_but_actions_do_not(self):
        async with stdio_client(self.params) as (reader, writer):
            async with ClientSession(reader, writer) as session:
                init = await session.initialize()
                self.assertEqual(init.serverInfo.name, "ai-collaboration")
                tools = (await session.list_tools()).tools
                self.assertEqual({tool.name for tool in tools}, {"send_message", "list_peers", "send_status"})
                sender = next(tool for tool in tools if tool.name == "send_message")
                self.assertEqual(set(sender.inputSchema["required"]), {"to", "text"})
                self.assertFalse(sender.inputSchema["additionalProperties"])
                self.assertFalse(sender.annotations.readOnlyHint)
                result = await session.call_tool("list_peers", {})
                self.assertTrue(result.isError)
                self.assertEqual(self.body(result)["state"], "not_sent")
                self.assertEqual(self.calls(), [])

    async def test_one_actual_connection_handles_two_concurrent_original_chats(self):
        async with stdio_client(self.params) as (reader, writer):
            async with ClientSession(reader, writer) as session:
                await session.initialize()
                a, b = await asyncio.gather(
                    session.call_tool("send_message", {"to": self.TARGET, "text": "A:中文\n'$()` @skill:test"},
                                      meta={self.META_KEY: self.SOURCE_A}),
                    session.call_tool("send_message", {"to": self.TARGET, "text": "B:independent"},
                                      meta={self.META_KEY: self.SOURCE_B}))
                self.assertFalse(a.isError); self.assertFalse(b.isError)
                self.assertEqual(self.body(a), {"state": "accepted", "to": self.TARGET, "stage": "native_host"})
                self.assertNotIn("FAKE_PRIVATE_DATA", a.model_dump_json())
                pairs = {(row["source"], row["text"]) for row in self.calls()}
                self.assertEqual(pairs, {(self.SOURCE_A, "A:中文\n'$()` @skill:test"), (self.SOURCE_B, "B:independent")})
                result = await session.call_tool("send_status", {"to": self.TARGET},
                                                 meta={self.META_KEY: self.SOURCE_B})
                self.assertFalse(result.isError)
                self.assertEqual(self.calls()[-1]["source"], self.SOURCE_B)

    async def test_invalid_source_reserved_address_and_forged_arguments_never_submit(self):
        async with stdio_client(self.params) as (reader, writer):
            async with ClientSession(reader, writer) as session:
                await session.initialize()
                cases = [
                    ({"to": self.TARGET, "text": "missing metadata"}, None),
                    ({"to": self.TARGET, "text": "unknown source"}, {self.META_KEY: "child"}),
                    ({"to": "A2A-1234", "text": "old reply"}, {self.META_KEY: self.SOURCE_A}),
                    ({"to": self.TARGET, "text": "forged", "source": "SenderA"}, {self.META_KEY: self.SOURCE_B}),
                ]
                for args, meta in cases:
                    result = await session.call_tool("send_message", args, meta=meta)
                    self.assertTrue(result.isError)
                    self.assertEqual(self.body(result)["state"], "not_sent")
                self.assertEqual(self.calls(), [])


class CodexStdioTests(StdioTests):
    HOST = "codex"
    META_KEY = "threadId"
    SOURCE_A, SOURCE_B, TARGET = "cx", "cx-b", "SenderA"


if __name__ == "__main__":
    unittest.main()
