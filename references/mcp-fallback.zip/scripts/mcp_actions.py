"""Small MCP actions over the existing collaboration core.

The stdio pipe is owned by the configured local host. Host metadata identifies
the current original chat; it is not cryptographic proof against another
process running with this user's privileges. Tool arguments never set a source.
"""
from collections.abc import Mapping
from pathlib import Path

import send
from message_delivery import failure_text, RECEIPT_STAGES, normalize_receipt
from workbuddy import BridgeError


HOST_META = {"workbuddy": "workbuddy.ai/conversationId", "codex": "threadId"}
HOST_ENV = {"workbuddy": "CODEBUDDY_SESSION_ID", "codex": "CODEX_THREAD_ID"}
FIELDS = {"send_message": {"to", "text"}, "list_peers": set(), "send_status": {"to"}}
STATES = {"waiting", "accepted", "queued", "uncertain", "not_sent", "ready"}


class McpActions:
    def __init__(self, root, *, host="workbuddy", core=None, config_loader=None):
        if host not in HOST_META:
            raise ValueError("Unsupported MCP host")
        self.root, self.host = Path(root), host
        self.core = core or send.run
        self.config_loader = config_loader or send.load_config

    def _context(self, meta):
        if not isinstance(meta, Mapping):
            raise BridgeError("宿主未提供当前原聊天，未发送")
        chat = meta.get(HOST_META[self.host])
        if (not isinstance(chat, str) or not chat or chat != chat.strip()
                or len(chat) > 200 or any(ord(c) < 32 or ord(c) == 127 for c in chat)):
            raise BridgeError("宿主未提供有效的当前原聊天，未发送")
        context = {HOST_ENV[self.host]: chat}
        local, peers = self.config_loader(self.root)
        if not send.message_enabled(local):
            raise BridgeError("MCP 入口需要先启用对话消息模式")
        origin = send.sender_at(local, peers, environ=context, strict=True)
        if (origin.get("software") != self.host or origin.get("verified") is not True
                or origin.get("registration_enabled", origin.get("enabled", True)) is not True):
            raise BridgeError("来源原聊天尚未核验或已停用，未发送")
        return context

    def invoke(self, name, arguments, meta):
        """No SDK dependency, environment mutation, task address, or arbitrary mode."""
        if name not in FIELDS:
            return {"state": "not_sent", "error": "未知协作工具"}
        if (not isinstance(arguments, dict) or set(arguments) != FIELDS[name]
                or any(not isinstance(value, str) or not value.strip() for value in arguments.values())):
            return {"state": "not_sent", "error": "工具参数不符"}
        if "to" in arguments and (len(arguments["to"]) > 200
                or any(ord(c) < 32 or ord(c) == 127 for c in arguments["to"])):
            return {"state": "not_sent", "error": "目标对话格式无效"}
        if "to" in arguments and arguments["to"].upper().startswith("A2A-"):
            return {"state": "not_sent", "error": "普通消息不能发往旧任务临时地址"}
        try:
            encoded = {key: value.encode("utf-8") for key, value in arguments.items()}
        except UnicodeEncodeError:
            return {"state": "not_sent", "error": "工具参数含无效Unicode，未发送"}
        if "text" in encoded and len(encoded["text"]) > 65536:
            return {"state": "not_sent", "error": failure_text(arguments["to"], arguments["text"])}
        started = False
        try:
            context = self._context(meta)
            request = {"mode": {"send_message": "send", "list_peers": "list", "send_status": "status"}[name],
                       **arguments}
            started = True
            result = self.core(request, self.root, sender_context=context)
            return self._public(name, result, arguments)
        except BridgeError as error:
            state = error.state if error.state in {"not_sent", "uncertain"} else "uncertain"
            if name == "send_message":
                return {"state": state, "error": failure_text(arguments["to"], arguments["text"], state)}
            return {"state": state, "error": "协作检查失败，请核对来源登记或连接"}
        except Exception:
            state = "uncertain" if started and name == "send_message" else "not_sent"
            if name == "send_message":
                return {"state": state, "error": failure_text(arguments["to"], arguments["text"], state)}
            return {"state": state, "error": "协作检查失败"}

    @staticmethod
    def _public(name, result, arguments):
        if not isinstance(result, dict):
            raise BridgeError("未取得有效收件状态", "uncertain")
        if name == "list_peers":
            rows = result.get("peers")
            if not isinstance(rows, list) or len(rows) > 5000:
                raise BridgeError("伙伴列表无效")
            return {"peers": [{key: row[key] for key in ("name", "software", "device")
                               if isinstance(row.get(key), str) and len(row[key]) <= 200}
                              for row in rows if isinstance(row, dict)]}
        state = result.get("state")
        if state not in STATES or (name == "send_message" and state == "ready"):
            raise BridgeError("收件状态无效", "uncertain")
        public = {"state": state, "to": arguments["to"]}
        if "stage" in result:
            if result["stage"] not in RECEIPT_STAGES:
                raise BridgeError("收件阶段无效", "uncertain")
            if state != "ready":
                normalize_receipt({"state": state, "stage": result["stage"]})
                public["stage"] = result["stage"]
        if state in {"not_sent", "uncertain"}:
            # Do not echo backend errors, even if short: third-party error text
            # can contain credentials. This tool's arguments identify the send.
            public["error"] = (failure_text(arguments["to"], arguments["text"], state)
                               if name == "send_message" else
                               "最近一次发送失败" if state == "not_sent" else "最近一次发送未确认")
        return public
