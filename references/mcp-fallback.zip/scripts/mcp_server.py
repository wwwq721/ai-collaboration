"""Shared stdio MCP entry; current source is read afresh for every tool call."""
import argparse
import asyncio
import json
import logging
from pathlib import Path
import sys

from mcp_actions import HOST_META, McpActions


ROOT = Path(__file__).resolve().parent.parent
VERSION = "2026.11.13.1"
INSTRUCTIONS = "用send_message联系已配对原聊天，日常只填目标和正文；收件确认由程序处理。送达未确认时查询原记录，不重复发送。"
TOOLS = (
    ("send_message", "向已配对的目标原聊天发送正文，程序自动确认收件。", {"to": {"type": "string", "minLength": 1, "maxLength": 200},
      "text": {"type": "string", "minLength": 1, "maxLength": 65536}}),
    ("list_peers", "按需列出已登记的目标对话。", {}),
    ("send_status", "查询向该目标最近一次发送的收件状态。", {"to": {"type": "string", "minLength": 1, "maxLength": 200}}),
)


class Inflight:
    """Canceled callers cannot create an unbounded queue of live send threads."""
    def __init__(self, maximum=16):
        self.maximum, self.tasks = maximum, set()

    async def call(self, action, name, arguments, meta):
        if len(self.tasks) >= self.maximum:
            return {"state": "not_sent", "error": "协作调用已满，未发送"}
        task = asyncio.create_task(asyncio.to_thread(action, name, arguments, meta))
        self.tasks.add(task)
        task.add_done_callback(self.tasks.discard)
        # The source snapshot and thread remain associated until completion,
        # even if MCP cancels its caller. No automatic retransmission follows.
        return await asyncio.shield(task)

    async def finish(self):
        pending = tuple(self.tasks)
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)


def metadata_from(context):
    meta = context.meta
    if meta is None:
        return {}
    if isinstance(meta, dict):
        return dict(meta)
    if hasattr(meta, "model_dump"):
        return meta.model_dump(by_alias=True, exclude_none=True)
    return {}


def create_server(root=ROOT, *, host="workbuddy", actions=None):
    # Official SDK is optional for the existing CLI/A2A entry points.
    from mcp.server.lowlevel import Server
    from mcp import types

    actions = actions or McpActions(root, host=host)
    server = Server("ai-collaboration", version=VERSION, instructions=INSTRUCTIONS)
    inflight = Inflight()

    @server.list_tools()
    async def tools():
        # Management UI probes do not have a current chat; discovery is public
        # static schema, whereas invoking an action always resolves its source.
        return [types.Tool(name=name, description=description,
                           inputSchema={"type": "object", "properties": properties,
                                        "required": list(properties), "additionalProperties": False},
                           annotations=types.ToolAnnotations(
                               readOnlyHint=name != "send_message", destructiveHint=False,
                               idempotentHint=name != "send_message", openWorldHint=name == "send_message"))
                for name, description, properties in TOOLS]

    @server.call_tool(validate_input=False)
    async def call(name, arguments):
        # Capture the request-local metadata before handing off to a thread.
        meta = metadata_from(server.request_context)
        result = await inflight.call(actions.invoke, name, arguments, meta)
        wire = json.dumps(result, ensure_ascii=False, separators=(",", ":"))
        return types.CallToolResult(content=[types.TextContent(type="text", text=wire)],
                                    isError=result.get("state") in {"not_sent", "uncertain"})

    return server, inflight


async def serve(root, host):
    from mcp.server.stdio import stdio_server
    server, inflight = create_server(root, host=host)
    try:
        async with stdio_server() as (reader, writer):
            await server.run(reader, writer, server.create_initialization_options())
    finally:
        await inflight.finish()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True, choices=tuple(HOST_META))
    parser.add_argument("--root", type=Path, default=ROOT)
    args = parser.parse_args()
    # No third-party debug request/body logging goes to the host's log or stdout.
    for name in ("mcp", "httpx", "httpcore"):
        logger = logging.getLogger(name)
        logger.handlers = [logging.NullHandler()]
        logger.propagate = False
        logger.setLevel(logging.CRITICAL)
    try:
        asyncio.run(serve(args.root, args.host))
    except ModuleNotFoundError:
        print("协作MCP依赖尚未就绪，请按现有安装指南准备requirements-mcp.txt。", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 0
    except Exception as error:
        print("协作MCP未能运行（" + type(error).__name__ + "）。", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
