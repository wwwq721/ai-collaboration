"""Preview, explicitly install, or remove this package's host MCP entry.

Only preview is the default. Existing host configuration stays private: outputs
contain the proposed public entry and opaque comparison hashes, never its other
servers or environment values. Host trust and tool permissions are not changed.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import secrets
import stat
import tempfile
try:
    import tomllib
except ModuleNotFoundError:
    tomllib = None

from managed_setup import SetupError, _json_bytes, _lock, _replace, _security


ROOT = Path(__file__).resolve().parents[1]
NAME = "ai-collaboration"
MAX_CONFIG_BYTES = 8 * 1024 * 1024
_CODEX_BLOCK_VERSION = 1
_CODEX_BEGIN = b"# BEGIN ai-collaboration managed MCP v1"
_CODEX_END = b"# END ai-collaboration managed MCP v1"


def _host(host):
    if host not in {"workbuddy", "codex"}:
        raise SetupError("尚未支持该宿主的配置安装")
    return host


def _absolute(path):
    return Path(os.path.abspath(os.fspath(path)))


def _no_links(path):
    """Do not follow symlinks, Windows junctions/reparse points, or file hardlinks."""
    path = _absolute(path)
    for current in reversed((path, *path.parents)):
        try:
            info = current.lstat()
        except FileNotFoundError:
            continue
        if (stat.S_ISLNK(info.st_mode)
                or getattr(info, "st_file_attributes", 0) & 0x400
                or (stat.S_ISREG(info.st_mode) and info.st_nlink != 1)):
            raise SetupError("配置或备份路径为链接；未读取或修改")
        if current != path and not stat.S_ISDIR(info.st_mode):
            raise SetupError("配置或备份目录无效")
    return path


def _read(path, *, missing=False):
    path = _no_links(path)
    try:
        flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
        with os.fdopen(os.open(path, flags), "rb") as stream:
            before = os.fstat(stream.fileno())
            if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
                raise SetupError("配置或备份不是独立普通文件")
            raw = stream.read(MAX_CONFIG_BYTES + 1)
            after = os.fstat(stream.fileno())
        _no_links(path)
        current = path.stat()
        if ((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
                != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
                or (current.st_dev, current.st_ino) != (after.st_dev, after.st_ino)):
            raise SetupError("读取期间配置发生变化；请重新预览")
        if len(raw) > MAX_CONFIG_BYTES:
            raise SetupError("配置或备份超过允许大小；未显示内容")
        return raw
    except FileNotFoundError:
        if missing:
            return None
        raise SetupError("所需配置或备份缺失") from None
    except OSError:
        raise SetupError("无法安全读取配置或备份；未显示内容") from None


def _object(raw, *, local=False):
    def pairs(values):
        result = {}
        for key, value in values:
            if key in result:
                raise ValueError("duplicate key")
            result[key] = value
        return result

    def invalid_constant(_):
        raise ValueError("non-JSON constant")

    try:
        value = json.loads(raw.decode("utf-8-sig" if local else "utf-8"),
                           object_pairs_hook=pairs, parse_constant=invalid_constant)
        if not isinstance(value, dict):
            raise ValueError("root")
        return value
    except (UnicodeError, ValueError, RecursionError):
        # WorkBuddy's UserMcpFile uses JSON.parse, not a JSONC parser.
        raise SetupError("配置须为合法纯 JSON 对象，不能含注释、重复键或异常数值；未修改") from None


def _config_path(root, host="workbuddy"):
    if _host(host) == "codex":
        configured = os.environ.get("CODEX_HOME")
        directory = Path(configured) if configured else Path.home() / ".codex"
        if not directory.is_absolute():
            raise SetupError("CODEX_HOME 须为绝对路径")
        return _no_links(directory / "config.toml")
    raw = _read(root / "local.json", missing=True)
    local = _object(raw, local=True) if raw is not None else {}
    configured = local.get("workbuddy_config")
    if configured is not None and not isinstance(configured, str):
        raise SetupError("本机 WorkBuddy 配置目录无效")
    if configured and configured.strip():
        directory = Path(configured)
        if not directory.is_absolute():
            raise SetupError("本机 WorkBuddy 配置目录须为绝对路径")
    else:
        directory = Path.home() / ".workbuddy"
    return _no_links(directory / "mcp.json")


def _entry(root, host="workbuddy"):
    _host(host)
    interpreter = root / ".mcp-env" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    entry = {"command": str(interpreter),
             "args": ["-X", "utf8", "-B", str(root / "scripts/mcp_server.py"), "--host", host]}
    if host == "workbuddy":
        entry["cwd"] = str(root)
    return entry


def _digest(raw):
    return hashlib.sha256(raw).hexdigest()


def _entry_hash(entry, host="workbuddy"):
    return _digest(json.dumps(entry, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                              allow_nan=host == "codex", **({"default": repr} if host == "codex" else {})).encode("utf-8"))


def _toml(raw):
    if tomllib is None:
        raise SetupError("Codex 配置处理需要 Python 3.11 或更高版本；WorkBuddy JSON 流程仍可使用")
    try:
        return tomllib.loads(raw.decode("utf-8"))
    except (UnicodeError, ValueError, RecursionError):
        raise SetupError("Codex 配置须为合法 TOML；未显示内容或修改") from None


def _snapshot(root, host="workbuddy"):
    _host(host)
    root = _no_links(root)
    path = _config_path(root, host)
    raw = _read(path, missing=True)
    document = _toml(raw or b"") if host == "codex" else (_object(raw) if raw is not None else {})
    servers = document.get("mcp_servers" if host == "codex" else "mcpServers", {})
    if not isinstance(servers, dict):
        raise SetupError("宿主 MCP 服务配置须为对象；未修改")
    desired = _entry(root, host)
    present = NAME in servers
    current_hash = _entry_hash(servers[NAME], host) if present else None
    file_hash = _digest(raw) if raw is not None else None
    fingerprint = _entry_hash({"path": str(path), "file": file_hash, "entry": current_hash,
                               "desired": _entry_hash(desired, host)})
    return {"root": root, "host": host, "path": path, "raw": raw, "document": document, "desired": desired,
            "present": present, "current_hash": current_hash, "file_hash": file_hash,
            "fingerprint": fingerprint}


def preview(root=ROOT, *, host="workbuddy"):
    snapshot = _snapshot(_absolute(root), host)
    same = snapshot["present"] and snapshot["current_hash"] == _entry_hash(snapshot["desired"], host)
    if same and host == "codex":
        same = _codex_managed(snapshot)
    return {"host": host, "config_path": str(snapshot["path"]), "entry_name": NAME,
            "entry": snapshot["desired"], "conflict": snapshot["present"] and not same,
            "already_configured": same, "fingerprint": snapshot["fingerprint"]}


def _cas(root, expected):
    latest = _snapshot(root, expected["host"])
    if (latest["path"] != expected["path"] or latest["file_hash"] != expected["file_hash"]
            or latest["current_hash"] != expected["current_hash"]
            or latest["fingerprint"] != expected["fingerprint"]):
        raise SetupError("配置自预览或备份后已变化；未覆盖，请重新预览")


def _mkdir(path, template):
    path = _no_links(path)
    if path.exists():
        if not path.is_dir():
            raise SetupError("所需配置或备份目录无效")
        return
    if not path.parent.is_dir():
        _mkdir(path.parent, template)
    path.mkdir()
    _no_links(path)
    _security(path, template)


def _stage(path, raw, template):
    _no_links(path)
    descriptor, name = tempfile.mkstemp(prefix=".mcp-", dir=path.parent)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            # Copy/protect the original DACL before writing any private bytes.
            _security(temporary, template)
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        _no_links(temporary)
        return temporary
    except Exception:
        temporary.unlink(missing_ok=True)
        raise


def _private_write(path, raw, template):
    temporary = _stage(path, raw, template)
    try:
        _no_links(path)
        _replace(path, temporary)
    finally:
        temporary.unlink(missing_ok=True)


def _backup(root, snapshot):
    template = snapshot["path"] if snapshot["raw"] is not None else root / "local.json"
    if not template.is_file():
        template = snapshot["path"].parent if snapshot["path"].parent.is_dir() else root
    _no_links(template)
    backup_root = root / "runtime/mcp-backups"
    _mkdir(backup_root, template)
    identity = secrets.token_hex(16)
    group = backup_root / identity
    group.mkdir()
    _security(group, template)
    if snapshot["raw"] is not None:
        _private_write(group / "before.raw", snapshot["raw"], template)
    manifest = {"version": 1, "host": snapshot["host"], "name": NAME,
                "config_path": str(snapshot["path"]), "entry_hash": _entry_hash(snapshot["desired"], snapshot["host"]),
                "original_exists": snapshot["raw"] is not None}
    if snapshot["host"] == "codex":
        manifest.update(managed_block_version=_CODEX_BLOCK_VERSION,
                        managed_block_hash=_digest(_codex_block(snapshot["desired"])))
    _private_write(group / "manifest.json", _json_bytes(manifest), template)
    return identity, template


def _publish(root, snapshot, document, template):
    _mkdir(snapshot["path"].parent, template)
    raw = document if snapshot["host"] == "codex" else _json_bytes(document)
    temporary = _stage(snapshot["path"], raw, template)
    try:
        # Compare both whole-file bytes and the owned entry immediately before
        # atomic replacement; unrelated concurrent changes require re-preview.
        _cas(root, snapshot)
        _no_links(snapshot["path"])
        _replace(snapshot["path"], temporary)
    finally:
        temporary.unlink(missing_ok=True)


def _same_toml(left, right):
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(_same_toml(left[key], right[key]) for key in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(_same_toml(a, b) for a, b in zip(left, right))
    if isinstance(left, float) and math.isnan(left):
        return math.isnan(right)
    return left == right


def _outside_codex_entry(document):
    outside = dict(document)
    if not isinstance(outside.get("mcp_servers", {}), dict):
        raise SetupError("Codex MCP 配置格式无效；拒绝发布")
    servers = dict(outside.get("mcp_servers", {}))
    servers.pop(NAME, None)
    if servers:
        outside["mcp_servers"] = servers
    else:
        outside.pop("mcp_servers", None)
    return outside


def _codex_block(desired):
    """A fixed independent TOML block; never serialize the user's document."""
    if (not isinstance(desired, dict) or set(desired) != {"command", "args"}
            or not isinstance(desired["command"], str) or not isinstance(desired["args"], list)
            or any(not isinstance(value, str) for value in desired["args"])):
        raise SetupError("本次 Codex 公开条目格式无效")
    try:
        body = (b"\n" + _CODEX_BEGIN + b"\n[mcp_servers." + json.dumps(NAME).encode("ascii") + b"]\n"
                + ("command = " + json.dumps(desired["command"], ensure_ascii=False)
                   + "\nargs = " + json.dumps(desired["args"], ensure_ascii=False) + "\n").encode("utf8")
                + _CODEX_END + b"\n")
    except UnicodeError:
        raise SetupError("本次 Codex 公开条目包含无效 Unicode；未修改") from None
    if not _same_toml(_toml(body).get("mcp_servers", {}).get(NAME), desired):
        raise SetupError("本次 Codex 管理块不能精确还原公开条目；未修改")
    return body


def _codex_managed(snapshot):
    raw = snapshot["raw"] or b""
    lines = raw.splitlines()
    return (lines.count(_CODEX_BEGIN) == lines.count(_CODEX_END) == 1
            and raw.count(_codex_block(snapshot["desired"])) == 1)


def _codex_edit(snapshot, action, manifest=None):
    """Append/remove only a precisely reconstructible owned block in memory."""
    original = snapshot["raw"] or b""
    block = _codex_block(snapshot["desired"])
    if action == "add":
        if _CODEX_BEGIN in original or _CODEX_END in original:
            raise SetupError("配置已有本工具管理标记；拒绝追加或猜测修复")
        raw = original + block
    else:
        if (not isinstance(manifest, dict) or manifest.get("managed_block_version") != _CODEX_BLOCK_VERSION
                or manifest.get("managed_block_hash") != _digest(block) or not _codex_managed(snapshot)):
            raise SetupError("Codex 管理块或标记与本次安装记录不同；拒绝移除")
        raw = original.replace(block, b"", 1)
    if len(raw) > MAX_CONFIG_BYTES:
        raise SetupError("Codex 配置追加后超过允许大小；未修改")
    try:
        edited = _toml(raw)
    except SetupError:
        raise SetupError("Codex 配置不能安全追加或移除独立管理块（可能使用封闭内联表）；未改写") from None
    if not _same_toml(_outside_codex_entry(snapshot["document"]), _outside_codex_entry(edited)):
        raise SetupError("管理块会改变其他 Codex 配置语义；拒绝发布")
    servers = edited.get("mcp_servers", {})
    if (not isinstance(servers, dict)
            or action == "add" and not _same_toml(servers.get(NAME), snapshot["desired"])
            or action == "remove" and NAME in servers):
        raise SetupError("Codex 管理块与本次公开条目不符；拒绝发布")
    return raw


def install(root=ROOT, *, confirm=False, expected=None, host="workbuddy"):
    if confirm is not True or not isinstance(expected, str) or not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise SetupError("安装需要显式确认及本次预览指纹；未修改")
    root = _no_links(_absolute(root))
    with _lock(root):
        snapshot = _snapshot(root, host)
        if snapshot["fingerprint"] != expected:
            raise SetupError("配置已变化；请重新预览后确认")
        if snapshot["present"]:
            if snapshot["current_hash"] != _entry_hash(snapshot["desired"], host):
                raise SetupError("同名 MCP 条目已存在且不同；拒绝覆盖")
            if host == "codex" and not _codex_managed(snapshot):
                raise SetupError("同名 Codex MCP 条目已存在且非本工具管理块；拒绝覆盖")
            return {"state": "unchanged", "config_path": str(snapshot["path"]), "entry_name": NAME}
        if (not Path(snapshot["desired"]["command"]).is_file()
                or not (root / "scripts/mcp_server.py").is_file()):
            raise SetupError("独立 MCP 环境或服务入口尚未就绪；未修改宿主配置")
        if host == "codex":
            document = _codex_edit(snapshot, "add")
        else:
            document = dict(snapshot["document"])
            document["mcpServers"] = {**document.get("mcpServers", {}), NAME: snapshot["desired"]}
        identity, template = _backup(root, snapshot)
        try:
            _publish(root, snapshot, document, template)
        except OSError:
            raise SetupError("安全写入失败；未显示配置或私密备份内容") from None
        return {"state": "installed", "config_path": str(snapshot["path"]), "entry_name": NAME,
                "installation_id": identity, "backup": "runtime/mcp-backups/" + identity,
                "host_refresh_required": True}


def rollback(root=ROOT, installation_id=None, *, confirm=False, host="workbuddy"):
    if confirm is not True or not isinstance(installation_id, str) or not re.fullmatch(r"[0-9a-f]{32}", installation_id):
        raise SetupError("回退需要显式确认及有效安装编号；未修改")
    root = _no_links(_absolute(root))
    with _lock(root):
        manifest = _object(_read(root / "runtime/mcp-backups" / installation_id / "manifest.json"))
        snapshot = _snapshot(root, host)
        if (manifest.get("version") != 1 or manifest.get("host") != host or manifest.get("name") != NAME
                or manifest.get("config_path") != str(snapshot["path"])
                or not isinstance(manifest.get("entry_hash"), str)
                or not re.fullmatch(r"[0-9a-f]{64}", manifest["entry_hash"])):
            raise SetupError("安装记录与当前目标不匹配；拒绝回退")
        if not snapshot["present"]:
            if host == "codex" and any(marker in (snapshot["raw"] or b"") for marker in (_CODEX_BEGIN, _CODEX_END)):
                raise SetupError("Codex 管理标记残留但条目缺失；拒绝猜测修复")
            return {"state": "unchanged", "config_path": str(snapshot["path"]), "entry_name": NAME}
        if snapshot["current_hash"] != manifest["entry_hash"]:
            raise SetupError("本次 MCP 条目已被修改；拒绝移除")
        if host == "codex":
            document = _codex_edit(snapshot, "remove", manifest)
        else:
            document = dict(snapshot["document"])
            document["mcpServers"] = dict(document.get("mcpServers", {}))
            del document["mcpServers"][NAME]
        try:
            _publish(root, snapshot, document, snapshot["path"])
        except OSError:
            raise SetupError("安全回退写入失败；未显示配置或私密备份内容") from None
        return {"state": "removed", "config_path": str(snapshot["path"]), "entry_name": NAME,
                "host_refresh_required": True}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", nargs="?", choices=("preview", "install", "rollback"), default="preview")
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--host", choices=("workbuddy", "codex"), default="workbuddy")
    parser.add_argument("--confirm", action="store_true")
    parser.add_argument("--expected")
    parser.add_argument("--installation")
    args = parser.parse_args(argv)
    try:
        if args.action == "preview":
            result = preview(args.root, host=args.host)
        elif args.action == "install":
            result = install(args.root, confirm=args.confirm, expected=args.expected, host=args.host)
        else:
            result = rollback(args.root, args.installation, confirm=args.confirm, host=args.host)
        print(json.dumps(result, ensure_ascii=True))
        return 0
    except SetupError as error:
        print(json.dumps({"error": str(error)}, ensure_ascii=True))
        return 2
    except Exception:
        print(json.dumps({"error": "MCP 准备失败；未显示配置或私密备份内容"}, ensure_ascii=True))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
